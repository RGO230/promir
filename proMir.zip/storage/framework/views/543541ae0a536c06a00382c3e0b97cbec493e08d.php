
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="card">
            <div class="card-header"><?php echo e(__('Создание нового курса')); ?></div>

            <div class="card-body">
                <form enctype="multipart/form-data" method="POST" action="<?php echo e(route('course.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="row mb-3">
                        <label  class="col-md-4 col-form-label text-md-end"><?php echo e(__('Название')); ?></label>

                        <div class="col-md-6">
                            <input type="text" class="form-control" name="title" required autofocus>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label  class="col-md-4 col-form-label text-md-end"><?php echo e(__('Описание')); ?></label>

                        <div class="col-md-6">
                            <textarea class="form-control" name="descr"></textarea>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label  class="col-md-4 col-form-label text-md-end"><?php echo e(__('Видео')); ?></label>

                        <div class="col-md-6">
                            <input type="text" class="form-control" name="video" required autofocus>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-md-4 col-form-label text-md-end"><?php echo e(__('Фотография')); ?></label>

                        <div class="col-md-6">
                            <input type="file" class="form-controll" id="customFile" name="file">
                        </div>
                    </div>
                  
    
                    <div class="row mb-0">
                        <div class="col-md-8 offset-md-4">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Вперёд')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OpenServer\domains\proMir\resources\views/course/create.blade.php ENDPATH**/ ?>