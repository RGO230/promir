
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="panel panel-default">
        <div style="display: flex; justify-content: space-between" class="panel-heading">
            <h2>Курсы</h2>  
            <a href="/course/create" class="btn btn-primary"> + Добавить новый</a>
        </div>
        <div class="panel-body">
            <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th>Название</th>
                    <th>Описание</th>
                    <th>Фотография</th>
                    <th>Видео</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->title); ?></td>
                        <td><?php echo e($item->descr); ?></td>
                        <td><img width="100" src="<?php echo e($item->image); ?>"></td>
                        <td><?php echo e($item->video); ?></td>
                        <td style="text-align:right;">
                            <a href="/course/<?php echo e($item->id); ?>/edit" class="btn btn-primary">Редактировать</a>
                            <a href="/course/<?php echo e($item->id); ?>/destroy" class="btn btn-danger">Удалить</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<style>
    table {
        width: 90%;
        margin-top: 20px;
    }
    table, th, td {
      border: 1px solid grey !important;
    }
    thead {
      position: sticky;
      top: 0;
      background: #2B2F33;
      color: white;
      border-color:white;
    }
    .wrap {
      margin: 0 !important;
      padding: 0 !important;
    }
  </style>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\OpenServer\domains\proMir\resources\views/course/index.blade.php ENDPATH**/ ?>